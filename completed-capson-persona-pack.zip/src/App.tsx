import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import PackageContents from "./components/PackageContents";
import SlashCommands from "./components/SlashCommands";
import Chapters from "./components/Chapters";
import Principles from "./components/Principles";
import Architecture from "./components/Architecture";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="bg-slate-950 text-white antialiased">
      <Navbar />
      <Hero />
      <PackageContents />
      <SlashCommands />
      <Chapters />
      <Principles />
      <Architecture />
      <Footer />
    </div>
  );
}
