import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Terminal, Sparkles } from "lucide-react";
import { slashCommands } from "../data/content";

export default function SlashCommands() {
  const [activeCommand, setActiveCommand] = useState(0);
  const [showResponse, setShowResponse] = useState(false);
  const [isTyping, setIsTyping] = useState(false);

  const handleRunCommand = (index: number) => {
    setActiveCommand(index);
    setShowResponse(false);
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      setShowResponse(true);
    }, 1200);
  };

  const cmd = slashCommands[activeCommand];

  return (
    <section id="commands" className="py-24 bg-slate-900">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-5xl font-black text-white mb-4">
            ⚡ Slash Commands
          </h2>
          <p className="text-slate-400 text-lg max-w-xl mx-auto">
            Governance macros built in. Click a command to see it in action.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-5 gap-6">
          {/* Command buttons */}
          <div className="lg:col-span-2 space-y-2">
            {slashCommands.map((sc, i) => (
              <motion.button
                key={sc.command}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.06 }}
                onClick={() => handleRunCommand(i)}
                className={`w-full flex items-center gap-3 px-5 py-3.5 rounded-xl text-left transition-all ${
                  activeCommand === i
                    ? "bg-amber-500/10 border border-amber-500/30 text-amber-300"
                    : "bg-slate-800/50 border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800"
                }`}
              >
                <Terminal className="w-4 h-4 flex-shrink-0" />
                <div className="flex-1">
                  <div className="font-mono text-sm font-bold">
                    {sc.command}
                  </div>
                  <div className="text-xs opacity-70 mt-0.5">
                    {sc.description}
                  </div>
                </div>
              </motion.button>
            ))}
          </div>

          {/* Terminal preview */}
          <div className="lg:col-span-3">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl"
            >
              {/* Terminal header */}
              <div className="flex items-center gap-2 px-5 py-3 border-b border-slate-800 bg-slate-900/80">
                <div className="w-3 h-3 rounded-full bg-red-500/70" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/70" />
                <div className="w-3 h-3 rounded-full bg-green-500/70" />
                <span className="ml-3 text-slate-500 text-xs font-mono">
                  capson-os — interactive
                </span>
              </div>

              {/* Terminal body */}
              <div className="p-5 min-h-[360px] font-mono text-sm">
                {/* Input line */}
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-emerald-400">❯</span>
                  <span className="text-white">{cmd.example}</span>
                  <motion.span
                    className="w-2 h-5 bg-amber-400 inline-block"
                    animate={{ opacity: [1, 0] }}
                    transition={{ duration: 0.8, repeat: Infinity }}
                  />
                </div>

                {/* Typing indicator */}
                <AnimatePresence mode="wait">
                  {isTyping && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="flex items-center gap-2 text-slate-500"
                    >
                      <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
                      <span>CAPSON is thinking...</span>
                      <motion.span
                        animate={{ opacity: [0.3, 1, 0.3] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                      >
                        ●●●
                      </motion.span>
                    </motion.div>
                  )}

                  {showResponse && !isTyping && (
                    <motion.div
                      key={cmd.command}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.4 }}
                      className="border-l-2 border-amber-500/30 pl-4"
                    >
                      {cmd.response.split("\n").map((line, i) => (
                        <div
                          key={i}
                          className={`py-0.5 ${
                            line.startsWith("**") || line.includes("**")
                              ? "text-white"
                              : line.startsWith("✅")
                              ? "text-emerald-400"
                              : line.startsWith("🔴") || line.startsWith("❌")
                              ? "text-red-400"
                              : line.startsWith("⚠️")
                              ? "text-yellow-400"
                              : line.startsWith("•")
                              ? "text-slate-300"
                              : line.startsWith("_")
                              ? "text-slate-500 italic"
                              : "text-slate-300"
                          }`}
                        >
                          {line || "\u00A0"}
                        </div>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
