import { motion } from "framer-motion";
import { ArrowUp, Package, Cpu, Zap } from "lucide-react";

export default function Footer() {
  return (
    <footer className="relative py-24 bg-slate-950 overflow-hidden">
      {/* Gradient top border */}
      <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-amber-500/50 to-transparent" />

      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-5xl font-black text-white mb-4">
            🚀 Next Upgrade
          </h2>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto mb-8">
            A tiny <span className="text-amber-400 font-semibold">FastAPI + Ollama</span> "persona router" skeleton
            that loads this pack, does retrieval from the handbook, and supports
            the slash commands — all running locally.
          </p>

          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-800/50 border border-slate-700 text-slate-300 text-sm">
              <Cpu className="w-4 h-4 text-amber-400" />
              Ollama Local LLM
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-800/50 border border-slate-700 text-slate-300 text-sm">
              <Zap className="w-4 h-4 text-emerald-400" />
              FastAPI Router
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-800/50 border border-slate-700 text-slate-300 text-sm">
              <Package className="w-4 h-4 text-blue-400" />
              RAG Retrieval
            </div>
          </div>

          <motion.a
            href="#"
            className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-bold rounded-xl hover:from-amber-400 hover:to-orange-400 transition-all shadow-lg shadow-amber-500/25"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Package className="w-5 h-5" />
            Download CAPSON_Persona_Pack.zip
          </motion.a>
        </motion.div>

        {/* Footer bottom */}
        <div className="border-t border-slate-800 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-white font-black text-xs">
              C
            </div>
            <span className="text-slate-500 text-sm">
              CAPSON — Community Action & Purpose Support Operating Node
            </span>
          </div>

          <div className="flex items-center gap-6">
            <span className="text-slate-600 text-sm">
              Local-first. Anti-guru. Human-scale.
            </span>
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
