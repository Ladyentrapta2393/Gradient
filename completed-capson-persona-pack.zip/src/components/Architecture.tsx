import { motion } from "framer-motion";
import { archNodes } from "../data/content";
import { ArrowRight } from "lucide-react";

export default function Architecture() {
  return (
    <section id="architecture" className="py-24 bg-slate-900">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-5xl font-black text-white mb-4">
            🏗️ Architecture
          </h2>
          <p className="text-slate-400 text-lg max-w-xl mx-auto">
            Local-first by design. No cloud dependency. Your community's data
            stays with your community.
          </p>
        </motion.div>

        {/* Architecture flow */}
        <div className="flex flex-wrap items-center justify-center gap-4 mb-16">
          {archNodes.map((node, i) => (
            <motion.div
              key={node.label}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="flex items-center gap-4"
            >
              <div className="bg-slate-800 border border-slate-700 rounded-xl p-5 text-center min-w-[140px] hover:border-amber-500/30 transition-colors group">
                <div className="text-3xl mb-2">{node.icon}</div>
                <div className="text-white font-semibold text-sm">
                  {node.label}
                </div>
                <div className="text-slate-500 text-xs mt-1">
                  {node.description}
                </div>
              </div>
              {i < archNodes.length - 1 && (
                <ArrowRight className="w-5 h-5 text-slate-600 hidden sm:block flex-shrink-0" />
              )}
            </motion.div>
          ))}
        </div>

        {/* Code snippet */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto"
        >
          <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden">
            <div className="flex items-center gap-2 px-5 py-3 border-b border-slate-800 bg-slate-900/80">
              <div className="w-3 h-3 rounded-full bg-red-500/70" />
              <div className="w-3 h-3 rounded-full bg-yellow-500/70" />
              <div className="w-3 h-3 rounded-full bg-green-500/70" />
              <span className="ml-3 text-slate-500 text-xs font-mono">
                main.py — FastAPI + Ollama skeleton
              </span>
            </div>
            <pre className="p-5 text-sm font-mono overflow-x-auto">
              <code>
                <span className="text-purple-400">from</span>
                <span className="text-slate-300"> fastapi </span>
                <span className="text-purple-400">import</span>
                <span className="text-emerald-400"> FastAPI</span>
                {"\n"}
                <span className="text-purple-400">from</span>
                <span className="text-slate-300"> capson </span>
                <span className="text-purple-400">import</span>
                <span className="text-emerald-400">
                  {" "}
                  PersonaRouter, HandbookRAG
                </span>
                {"\n\n"}
                <span className="text-slate-300">app = </span>
                <span className="text-emerald-400">FastAPI</span>
                <span className="text-slate-500">()</span>
                {"\n"}
                <span className="text-slate-300">persona = </span>
                <span className="text-emerald-400">PersonaRouter</span>
                <span className="text-slate-500">(</span>
                {"\n"}
                <span className="text-slate-500">    </span>
                <span className="text-amber-400">system_prompt</span>
                <span className="text-slate-500">=</span>
                <span className="text-green-300">"system_prompt.txt"</span>
                <span className="text-slate-500">,</span>
                {"\n"}
                <span className="text-slate-500">    </span>
                <span className="text-amber-400">handbook</span>
                <span className="text-slate-500">=</span>
                <span className="text-emerald-400">HandbookRAG</span>
                <span className="text-slate-500">(</span>
                <span className="text-green-300">
                  "capson_handbook_ch1-5.md"
                </span>
                <span className="text-slate-500">),</span>
                {"\n"}
                <span className="text-slate-500">    </span>
                <span className="text-amber-400">commands</span>
                <span className="text-slate-500">=</span>
                <span className="text-green-300">"command_macros.md"</span>
                {"\n"}
                <span className="text-slate-500">)</span>
                {"\n\n"}
                <span className="text-slate-500">@</span>
                <span className="text-amber-400">app.post</span>
                <span className="text-slate-500">(</span>
                <span className="text-green-300">"/chat"</span>
                <span className="text-slate-500">)</span>
                {"\n"}
                <span className="text-purple-400">async def</span>
                <span className="text-blue-400"> chat</span>
                <span className="text-slate-500">(</span>
                <span className="text-amber-400">msg</span>
                <span className="text-slate-500">: </span>
                <span className="text-emerald-400">str</span>
                <span className="text-slate-500">):</span>
                {"\n"}
                <span className="text-slate-500">    </span>
                <span className="text-purple-400">return</span>
                <span className="text-slate-300"> persona.</span>
                <span className="text-blue-400">respond</span>
                <span className="text-slate-500">(</span>
                <span className="text-slate-300">msg</span>
                <span className="text-slate-500">)</span>
              </code>
            </pre>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
