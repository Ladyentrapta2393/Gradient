import { motion } from "framer-motion";
import { Shield, Eye, Users, Scale, Heart, Lightbulb } from "lucide-react";

const principles = [
  {
    icon: Shield,
    title: "Never Override Governance",
    description:
      "The AI defers to the handbook. It can't invent rules that aren't written in Chapters 1–5.",
    color: "text-amber-400",
    bgColor: "bg-amber-500/10",
  },
  {
    icon: Eye,
    title: "Cite Everything",
    description:
      "Every governance claim references a specific chapter and section. Traceable, auditable.",
    color: "text-blue-400",
    bgColor: "bg-blue-500/10",
  },
  {
    icon: Users,
    title: "Defer to Cell Consensus",
    description:
      "Local decisions belong to the cell. CAPSON facilitates — it doesn't dictate.",
    color: "text-emerald-400",
    bgColor: "bg-emerald-500/10",
  },
  {
    icon: Scale,
    title: "Surface Tensions",
    description:
      "Conflicts are signal, not failure. The system escalates fairly without flattening disagreement.",
    color: "text-purple-400",
    bgColor: "bg-purple-500/10",
  },
  {
    icon: Heart,
    title: "Accountability as Care",
    description:
      "Shipping commitments isn't punishment. It's how the community holds each other with dignity.",
    color: "text-rose-400",
    bgColor: "bg-rose-500/10",
  },
  {
    icon: Lightbulb,
    title: "Anti-Guru",
    description:
      'The AI says "I don\'t know" when the handbook is silent. No guru-bloat, no invented authority.',
    color: "text-orange-400",
    bgColor: "bg-orange-500/10",
  },
];

export default function Principles() {
  return (
    <section className="py-24 bg-slate-950">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-5xl font-black text-white mb-4">
            🛡️ Non-Negotiables
          </h2>
          <p className="text-slate-400 text-lg max-w-xl mx-auto">
            The hard rules baked into the persona. These can't be overridden by
            any prompt.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {principles.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 hover:border-slate-700 transition-all group"
            >
              <div
                className={`inline-flex items-center justify-center w-12 h-12 rounded-xl ${p.bgColor} mb-4`}
              >
                <p.icon className={`w-6 h-6 ${p.color}`} />
              </div>
              <h3 className="text-white font-bold text-lg mb-2">{p.title}</h3>
              <p className="text-slate-400 text-sm leading-relaxed">
                {p.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
