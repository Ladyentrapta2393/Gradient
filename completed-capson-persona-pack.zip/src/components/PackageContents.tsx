import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { File, ChevronRight, X } from "lucide-react";
import { packageFiles, type PackageFile } from "../data/content";

function FilePreview({ file, onClose }: { file: PackageFile; onClose: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full max-h-[80vh] overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-700/50">
          <div className="flex items-center gap-3">
            <span className="text-2xl">{file.icon}</span>
            <div>
              <h3 className="text-white font-semibold">
                {file.name}
                <span className="text-amber-400">{file.ext}</span>
              </h3>
              <p className="text-slate-500 text-sm">{file.description}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        {/* Content */}
        <div className="p-6 overflow-auto max-h-[60vh]">
          <div className="font-mono text-sm space-y-0">
            {file.lines.map((line, i) => (
              <div
                key={i}
                className="flex gap-4 py-0.5 hover:bg-slate-800/50 rounded px-2 -mx-2"
              >
                <span className="text-slate-600 select-none w-6 text-right flex-shrink-0">
                  {i + 1}
                </span>
                <span
                  className={
                    line.startsWith("#")
                      ? "text-amber-400 font-bold"
                      : line.startsWith("-") || line.startsWith("/")
                      ? "text-emerald-400"
                      : line.startsWith("##")
                      ? "text-blue-400"
                      : line === ""
                      ? ""
                      : "text-slate-300"
                  }
                >
                  {line || "\u00A0"}
                </span>
              </div>
            ))}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function PackageContents() {
  const [selectedFile, setSelectedFile] = useState<PackageFile | null>(null);

  return (
    <section id="contents" className="py-24 bg-slate-950">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-5xl font-black text-white mb-4">
            📦 What's in the Pack
          </h2>
          <p className="text-slate-400 text-lg max-w-xl mx-auto">
            Everything you need to deploy CAPSON as a local AI persona.
            Click any file to preview.
          </p>
        </motion.div>

        {/* File tree */}
        <div className="bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden">
          {/* Header bar */}
          <div className="flex items-center gap-2 px-6 py-3 border-b border-slate-800 bg-slate-900">
            <div className="w-3 h-3 rounded-full bg-red-500/70" />
            <div className="w-3 h-3 rounded-full bg-yellow-500/70" />
            <div className="w-3 h-3 rounded-full bg-green-500/70" />
            <span className="ml-4 text-slate-500 text-sm font-mono">
              CAPSON_Persona_Pack/
            </span>
          </div>

          {/* Files */}
          <div className="divide-y divide-slate-800/50">
            {packageFiles.map((file, index) => (
              <motion.button
                key={file.name}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.08 }}
                onClick={() => setSelectedFile(file)}
                className="w-full flex items-center gap-4 px-6 py-4 hover:bg-slate-800/50 transition-colors text-left group"
              >
                <span className="text-2xl">{file.icon}</span>
                <File className="w-4 h-4 text-slate-600 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <span className="text-white font-mono text-sm">
                    {file.name}
                    <span className="text-amber-400">{file.ext}</span>
                  </span>
                  <p className="text-slate-500 text-sm truncate mt-0.5">
                    {file.description}
                  </p>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-amber-400 transition-colors flex-shrink-0" />
              </motion.button>
            ))}

            {/* PDF file (non-interactive) */}
            <div className="flex items-center gap-4 px-6 py-4 text-left opacity-60">
              <span className="text-2xl">📄</span>
              <File className="w-4 h-4 text-slate-600 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <span className="text-white font-mono text-sm">
                  CAPSON_Community_Handbook_Ch1-5
                  <span className="text-amber-400">.pdf</span>
                </span>
                <p className="text-slate-500 text-sm truncate mt-0.5">
                  Human-readable PDF for circulation
                </p>
              </div>
              <span className="text-xs text-slate-600 border border-slate-700 px-2 py-0.5 rounded">
                PDF
              </span>
            </div>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {selectedFile && (
          <FilePreview
            file={selectedFile}
            onClose={() => setSelectedFile(null)}
          />
        )}
      </AnimatePresence>
    </section>
  );
}
