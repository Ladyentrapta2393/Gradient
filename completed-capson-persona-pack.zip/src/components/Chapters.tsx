import { motion } from "framer-motion";
import { BookOpen, Check } from "lucide-react";
import { chapters } from "../data/content";

export default function Chapters() {
  return (
    <section id="chapters" className="py-24 bg-slate-950">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-5xl font-black text-white mb-4">
            📖 The Constitution
          </h2>
          <p className="text-slate-400 text-lg max-w-xl mx-auto">
            Five chapters that form the governance backbone. Every AI response
            cites these — no invented rules.
          </p>
        </motion.div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {chapters.map((ch, index) => (
            <motion.div
              key={ch.number}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={`group relative bg-slate-900/50 border border-slate-800 rounded-2xl p-6 hover:border-slate-700 transition-all ${
                index === 4 ? "sm:col-span-2 lg:col-span-1" : ""
              }`}
            >
              {/* Chapter number badge */}
              <div
                className={`inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gradient-to-r ${ch.color} text-white text-xs font-bold mb-4`}
              >
                <BookOpen className="w-3 h-3" />
                Chapter {ch.number}
              </div>

              <h3 className="text-xl font-bold text-white mb-1">{ch.title}</h3>
              <p className="text-slate-500 text-sm mb-4">{ch.subtitle}</p>

              <ul className="space-y-2">
                {ch.keyPoints.map((point, i) => (
                  <li
                    key={i}
                    className="flex items-start gap-2 text-sm text-slate-400"
                  >
                    <Check className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
                    {point}
                  </li>
                ))}
              </ul>

              {/* Subtle glow on hover */}
              <div
                className={`absolute inset-0 rounded-2xl bg-gradient-to-r ${ch.color} opacity-0 group-hover:opacity-[0.03] transition-opacity pointer-events-none`}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
