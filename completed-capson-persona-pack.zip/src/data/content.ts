export interface PackageFile {
  name: string;
  ext: string;
  description: string;
  icon: string;
  lines: string[];
}

export const packageFiles: PackageFile[] = [
  {
    name: "system_prompt",
    ext: ".txt",
    description: "Compact CAPSON OS persona core — non-negotiables + behaviour rules",
    icon: "🧠",
    lines: [
      "# CAPSON OS — System Persona Core",
      "",
      "You are CAPSON: the Community Action & Purpose",
      "Support Operating Node.",
      "",
      "## Non-Negotiables",
      "- Never override chapter governance",
      "- Always cite handbook section when advising",
      "- Defer to cell consensus on local decisions",
      "- Flag conflicts to mediator, don't resolve",
      "- Protect member autonomy above efficiency",
    ],
  },
  {
    name: "developer_prompt",
    ext: ".txt",
    description: "Constitution & retrieval policy — how to use the handbook without guru-bloat",
    icon: "📜",
    lines: [
      "# Developer Prompt — Constitution/Retrieval Policy",
      "",
      "## Purpose",
      "Guide LLM retrieval from the CAPSON handbook",
      "without creating guru dependency.",
      "",
      "## Rules",
      "1. Cite chapter + section for every claim",
      "2. Say 'I don't know' when handbook is silent",
      "3. Never invent governance that isn't written",
      "4. Surface tensions, don't flatten them",
    ],
  },
  {
    name: "capson_handbook_ch1-5",
    ext: ".md",
    description: "Chapters 1–5 in clean Markdown — the constitutional backbone",
    icon: "📖",
    lines: [
      "# CAPSON Community Handbook",
      "",
      "## Ch 1: What Is CAPSON?",
      "A decentralised community operating system...",
      "",
      "## Ch 2: Cell Structure",
      "Small groups (5–12) with rotating roles...",
      "",
      "## Ch 3: Decision Making",
      "Consent-based, not consensus-based...",
      "",
      "## Ch 4: Conflict Resolution",
      "Three-tier escalation: self → cell → mediator",
      "",
      "## Ch 5: Shipping & Accountability",
      "Weekly loops, public commitments, no ghost mode",
    ],
  },
  {
    name: "command_macros",
    ext: ".md",
    description: "Slash commands — /loop /decision /meeting /conflict /ship /name-removal /audit",
    icon: "⚡",
    lines: [
      "# CAPSON Slash Commands",
      "",
      "/loop    — Start a weekly reflection cycle",
      "/decision — Initiate consent-based proposal",
      "/meeting  — Generate async meeting template",
      "/conflict — Open structured conflict process",
      "/ship     — Log a shipped commitment",
      "/name-removal — Request member removal",
      "/audit    — Run governance health check",
    ],
  },
  {
    name: "onboarding_script",
    ext: ".md",
    description: "10–15 min cell onboarding script for new members",
    icon: "🚀",
    lines: [
      "# New Member Onboarding Script",
      "## Duration: 10–15 minutes",
      "",
      "### Phase 1: Welcome (2 min)",
      "Introduce the cell, explain CAPSON purpose",
      "",
      "### Phase 2: Structure (5 min)",
      "Walk through roles, loops, decision process",
      "",
      "### Phase 3: First Commitment (3 min)",
      "New member makes their first /ship pledge",
      "",
      "### Phase 4: Q&A (5 min)",
      "Open floor, assign onboarding buddy",
    ],
  },
  {
    name: "README",
    ext: ".md",
    description: "Recommended local-first architecture notes",
    icon: "🏗️",
    lines: [
      "# CAPSON Persona Pack — README",
      "",
      "## Architecture: Local-First",
      "- System prompt loaded at init",
      "- Handbook chunks for RAG retrieval",
      "- Slash commands as tool-use macros",
      "- No cloud dependency required",
      "",
      "## Quick Start",
      "1. Load system_prompt.txt as system message",
      "2. Index handbook for retrieval",
      "3. Register command_macros as tools",
    ],
  },
];

export interface SlashCommand {
  command: string;
  label: string;
  description: string;
  example: string;
  response: string;
}

export const slashCommands: SlashCommand[] = [
  {
    command: "/loop",
    label: "Weekly Loop",
    description: "Start a weekly reflection cycle for your cell",
    example: "/loop — what shipped, what's stuck, what's next",
    response: `📋 **Weekly Loop — Cell "Ember"**\n\n✅ **Shipped:** Community garden schedule published\n🔴 **Stuck:** Budget approval pending Ch.3 consent\n➡️ **Next:** Draft proposal for neighbourhood event\n\n_All members: respond by Friday 6pm._`,
  },
  {
    command: "/decision",
    label: "Decision",
    description: "Initiate a consent-based proposal process",
    example: '/decision "Should we open a shared tool library?"',
    response: `🗳️ **Consent Proposal Opened**\n\n**Proposal:** Open a shared tool library\n**Proposer:** @member\n**Deadline:** 72 hours\n\nRespond with:\n• ✅ Consent (no paramount objection)\n• 🟡 Concern (state it)\n• 🔴 Objection (must be paramount)\n\n_Per Handbook Ch.3 §2_`,
  },
  {
    command: "/meeting",
    label: "Meeting",
    description: "Generate an async meeting template",
    example: "/meeting planning-session",
    response: `📝 **Async Meeting: Planning Session**\n\n**Check-in round:** How are you arriving?\n**Agenda:**\n1. Review last /loop outcomes\n2. New proposals (if any)\n3. Blockers & support requests\n\n**Closing round:** One word checkout\n\n_Template per Ch.2 §4 — Rotate facilitator_`,
  },
  {
    command: "/conflict",
    label: "Conflict",
    description: "Open a structured conflict resolution process",
    example: "/conflict between @alice @bob re: resource allocation",
    response: `⚖️ **Conflict Process Initiated**\n\n**Parties:** @alice, @bob\n**Topic:** Resource allocation\n**Tier:** 1 (Self-resolution first)\n\n**Steps:**\n1. Each party writes their perspective (24h)\n2. Exchange & reflect (24h)\n3. If unresolved → escalate to cell (Tier 2)\n\n_Per Handbook Ch.4 §1-3_`,
  },
  {
    command: "/ship",
    label: "Ship",
    description: "Log a shipped commitment publicly",
    example: '/ship "Published the community newsletter #4"',
    response: `🚢 **Commitment Shipped!**\n\n**What:** Published the community newsletter #4\n**By:** @member\n**Date:** Today\n**Loop:** Week 12\n\n_Logged to cell ledger. Accountability is care._\n_Per Handbook Ch.5 §1_`,
  },
  {
    command: "/audit",
    label: "Audit",
    description: "Run a governance health check on your cell",
    example: "/audit cell-ember",
    response: `🔍 **Governance Health Check — Cell "Ember"**\n\n✅ Roles rotated this month\n✅ Weekly loops: 4/4 completed\n⚠️ 1 open conflict > 7 days (escalate?)\n✅ All members shipped ≥ 1 commitment\n❌ No facilitator assigned for next cycle\n\n**Score: 78/100** — Healthy with attention needed\n_Per Handbook Ch.5 §3_`,
  },
];

export interface Chapter {
  number: number;
  title: string;
  subtitle: string;
  keyPoints: string[];
  color: string;
}

export const chapters: Chapter[] = [
  {
    number: 1,
    title: "What Is CAPSON?",
    subtitle: "The philosophical and practical foundation",
    keyPoints: [
      "Decentralised community operating system",
      "Built on trust, not hierarchy",
      "Designed for real human messiness",
      "Anti-guru, pro-collective intelligence",
    ],
    color: "from-amber-500 to-orange-600",
  },
  {
    number: 2,
    title: "Cell Structure",
    subtitle: "How small groups self-organise",
    keyPoints: [
      "Cells of 5–12 members",
      "Rotating roles prevent power concentration",
      "Autonomous but interconnected",
      "Organic growth through cell division",
    ],
    color: "from-emerald-500 to-teal-600",
  },
  {
    number: 3,
    title: "Decision Making",
    subtitle: "Consent-based, not consensus-based",
    keyPoints: [
      "Proposals need no objections, not full agreement",
      "Paramount objections only — not preferences",
      "72-hour async windows",
      "Documented in cell ledger",
    ],
    color: "from-blue-500 to-indigo-600",
  },
  {
    number: 4,
    title: "Conflict Resolution",
    subtitle: "Three-tier structured escalation",
    keyPoints: [
      "Tier 1: Self-resolution between parties",
      "Tier 2: Cell-supported mediation",
      "Tier 3: External mediator if needed",
      "Conflict is signal, not failure",
    ],
    color: "from-purple-500 to-violet-600",
  },
  {
    number: 5,
    title: "Shipping & Accountability",
    subtitle: "Weekly loops and public commitments",
    keyPoints: [
      "Weekly reflection loops",
      "Public commitments, no ghost mode",
      "Accountability as care, not punishment",
      "Governance health audits",
    ],
    color: "from-rose-500 to-pink-600",
  },
];

export interface ArchNode {
  label: string;
  description: string;
  icon: string;
}

export const archNodes: ArchNode[] = [
  {
    label: "System Prompt",
    description: "Persona core loaded at init",
    icon: "🧠",
  },
  {
    label: "RAG Retrieval",
    description: "Handbook chunks indexed locally",
    icon: "🔍",
  },
  {
    label: "Slash Commands",
    description: "Tool-use macros for governance",
    icon: "⚡",
  },
  {
    label: "Ollama / LLM",
    description: "Local inference, no cloud needed",
    icon: "🤖",
  },
  {
    label: "FastAPI Router",
    description: "Persona router skeleton",
    icon: "🔀",
  },
  {
    label: "Cell Interface",
    description: "Where humans interact",
    icon: "👥",
  },
];
